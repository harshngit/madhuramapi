const express = require("express");
const router = express.Router();
const { pool } = require("../db");
const multer = require("multer");
const path = require("path");
const fs = require("fs");
const nodemailer = require("nodemailer");
const { generatePOPdf } = require("../utils/po_pdf");
const { logActivity } = require("./dashboard"); // adjust path if needed


// Ensure upload directory exists
const uploadDir = path.join(__dirname, "../../uploads/po");
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

// Configure Multer
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    // Keep original extension, prepend timestamp for uniqueness
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
    cb(null, uniqueSuffix + path.extname(file.originalname));
  },
});

const upload = multer({ storage: storage });

/**
 * @swagger
 * tags:
 *   name: PO
 *   description: Purchase Order management
 */

/**
 * @swagger
 * /api/po/upload:
 *   post:
 *     summary: Upload a file for PO
 *     tags: [PO]
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             properties:
 *               file:
 *                 type: string
 *                 format: binary
 *     responses:
 *       200:
 *         description: File uploaded successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 filePath:
 *                   type: string
 *                   description: The path to the uploaded file
 *       400:
 *         description: No file uploaded
 */
router.post("/upload", upload.single("file"), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: "No file uploaded" });
  }
  // Return the relative path to be stored in the database
  const filePath = `/uploads/po/${req.file.filename}`;
  res.json({ filePath });

  if (req.body.user_id) {
    logActivity({
      action: "uploaded",
      entity_type: "po_file",
      entity_id: null,
      entity_name: req.file.originalname,
      performed_by: req.body.user_id,
      performed_by_name: req.body.user_name || null,
      meta: { filePath }
    });
  }
});

/**
 * @swagger
 * /api/po:
 *   post:
 *     summary: Create a new Purchase Order (PO)
 *     tags: [PO]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               project_id:
 *                 type: integer
 *               sample_id:
 *                 type: integer
 *               company_name:
 *                 type: string
 *               company_subtitle:
 *                 type: string
 *               company_email:
 *                 type: string
 *               company_gst:
 *                 type: string
 *               indent_no:
 *                 type: string
 *               indent_date:
 *                 type: string
 *                 format: date
 *               order_no:
 *                 type: string
 *               po_date:
 *                 type: string
 *                 format: date
 *               vendor_name:
 *                 type: string
 *               site:
 *                 type: string
 *               contact_person:
 *                 type: string
 *               vendor_address:
 *                 type: string
 *               primary_contact_name:
 *                 type: string
 *               primary_contact_number:
 *                 type: string
 *               secondary_contact_number:
 *                 type: string
 *               secondary_contact_name:
 *                 type: string
 *               items:
 *                 type: array
 *                 items:
 *                   type: object
 *                   properties:
 *                     srno:
 *                       type: integer
 *                     hsn:
 *                       type: string
 *                     description:
 *                       type: string
 *                     qty:
 *                       type: number
 *                     UOM:
 *                       type: string
 *                     Rate:
 *                       type: number
 *                     Amount:
 *                       type: number
 *                     remark:
 *                       type: string
 *               discount:
 *                 type: number
 *               discount_amount:
 *                 type: number
 *               after_discount:
 *                 type: number
 *               cgst:
 *                 type: number
 *               cgst_amount:
 *                 type: number
 *               sgst:
 *                 type: number
 *               sgst_amount:
 *                 type: number
 *               total_amount:
 *                 type: number
 *               delivery:
 *                 type: string
 *               payment:
 *                 type: string
 *               notes:
 *                 type: string
 *               status:
 *                 type: string
 *                 default: created
 *     responses:
 *       201:
 *         description: PO created successfully
 *       500:
 *         description: Internal server error
 */
router.post("/", async (req, res) => {
  const {
    project_id,
    sample_id,
    company_name,
    company_subtitle,
    company_email,
    company_gst,
    indent_no,
    indent_date,
    order_no,
    po_date,
    vendor_name,
    site,
    contact_person,
    vendor_address,
    primary_contact_name,
    primary_contact_number,
    secondary_contact_number,
    secondary_contact_name,
    items,
    discount,
    discount_amount,
    after_discount,
    cgst,
    cgst_amount,
    sgst,
    sgst_amount,
    total_amount,
    delivery,
    payment,
    notes,
    status,
  } = req.body;

  try {
    const result = await pool.query(
      `INSERT INTO pos (
        project_id, sample_id, company_name, company_subtitle, company_email, company_gst,
        indent_no, indent_date, order_no, po_date, vendor_name, site,
        contact_person, vendor_address, primary_contact_name, primary_contact_number,
        secondary_contact_number, secondary_contact_name, items, discount,
        discount_amount, after_discount, cgst, cgst_amount, sgst, sgst_amount,
        total_amount, delivery, payment, notes, status
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22, $23, $24, $25, $26, $27, $28, $29, $30, $31) RETURNING *`,
      [
        project_id,
        sample_id || null,
        company_name,
        company_subtitle,
        company_email,
        company_gst,
        indent_no,
        indent_date,
        order_no,
        po_date,
        vendor_name,
        site,
        contact_person,
        vendor_address,
        primary_contact_name,
        primary_contact_number,
        secondary_contact_number,
        secondary_contact_name,
        JSON.stringify(items || []),
        discount,
        discount_amount,
        after_discount,
        cgst,
        cgst_amount,
        sgst,
        sgst_amount,
        total_amount,
        delivery,
        payment,
        notes,
        status || 'created',
      ]
    );
    res.status(201).json(result.rows[0]);
    logActivity({
  action: "created",
  entity_type: "po",
  entity_id: result.rows[0].po_id,
  entity_name: `PO #${result.rows[0].po_id}`,
  performed_by: req.body.created_by || null,
  performed_by_name: req.body.created_by_name || null,
  meta: {
    project_id: result.rows[0].project_id,
    sample_id: result.rows[0].sample_id,
    company_name: result.rows[0].company_name,
  },
});
  } catch (error) {
    console.error("Error creating PO:", error);
    res.status(500).json({ error: error.message });
  }
});

/**
 * @swagger
 * /api/po/project/{projectId}:
 *   get:
 *     summary: Get all POs for a specific project
 *     tags: [PO]
 *     parameters:
 *       - in: path
 *         name: projectId
 *         required: true
 *         schema:
 *           type: integer
 *         description: Project ID
 *     responses:
 *       200:
 *         description: List of POs
 *       500:
 *         description: Internal server error
 */
router.get("/project/:projectId", async (req, res) => {
  const { projectId } = req.params;
  try {
    const result = await pool.query("SELECT * FROM pos WHERE project_id = $1 ORDER BY created_at DESC", [projectId]);
    res.json(result.rows);
  } catch (error) {
    console.error("Error fetching POs:", error);
    res.status(500).json({ error: error.message });
  }
});

/**
 * @swagger
 * /api/po/sample/{sampleId}:
 *   get:
 *     summary: Get all POs for a specific sample
 *     tags: [PO]
 *     parameters:
 *       - in: path
 *         name: sampleId
 *         required: true
 *         schema:
 *           type: integer
 *         description: Sample ID
 *     responses:
 *       200:
 *         description: List of POs for the sample
 *       500:
 *         description: Internal server error
 */
router.get("/sample/:sampleId", async (req, res) => {
  const { sampleId } = req.params;
  try {
    const result = await pool.query("SELECT * FROM pos WHERE sample_id = $1 ORDER BY created_at DESC", [sampleId]);
    res.json(result.rows);
  } catch (error) {
    console.error("Error fetching POs by sample:", error);
    res.status(500).json({ error: error.message });
  }
});

/**
 * @swagger
 * /api/po/{id}:
 *   get:
 *     summary: Get a single PO by ID
 *     tags: [PO]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: PO ID
 *     responses:
 *       200:
 *         description: PO details
 *       404:
 *         description: PO not found
 *       500:
 *         description: Internal server error
 */
router.get("/:id", async (req, res) => {
  const { id } = req.params;
  try {
    const result = await pool.query("SELECT * FROM pos WHERE po_id = $1", [id]);
    if (result.rows.length === 0) {
      return res.status(404).json({ error: "PO not found" });
    }
    res.json(result.rows[0]);
  } catch (error) {
    console.error("Error fetching PO:", error);
    res.status(500).json({ error: error.message });
  }
});

/**
 * @swagger
 * /api/po/{id}:
 *   put:
 *     summary: Update an existing PO
 *     tags: [PO]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: PO ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/POUpdate'
 *     responses:
 *       200:
 *         description: PO updated successfully
 *       404:
 *         description: PO not found
 *       500:
 *         description: Internal server error
 */
router.put("/:id", async (req, res) => {
  const { id } = req.params;
  const {
    sample_id,
    company_name,
    company_subtitle,
    company_email,
    company_gst,
    indent_no,
    indent_date,
    order_no,
    po_date,
    vendor_name,
    site,
    contact_person,
    vendor_address,
    primary_contact_name,
    primary_contact_number,
    secondary_contact_number,
    secondary_contact_name,
    items,
    discount,
    discount_amount,
    after_discount,
    cgst,
    cgst_amount,
    sgst,
    sgst_amount,
    total_amount,
    delivery,
    payment,
    notes,
    status,
  } = req.body;

  try {
    const result = await pool.query(
      `UPDATE pos SET
        sample_id = COALESCE($1, sample_id),
        company_name = COALESCE($2, company_name),
        company_subtitle = COALESCE($3, company_subtitle),
        company_email = COALESCE($4, company_email),
        company_gst = COALESCE($5, company_gst),
        indent_no = COALESCE($6, indent_no),
        indent_date = COALESCE($7, indent_date),
        order_no = COALESCE($8, order_no),
        po_date = COALESCE($9, po_date),
        vendor_name = COALESCE($10, vendor_name),
        site = COALESCE($11, site),
        contact_person = COALESCE($12, contact_person),
        vendor_address = COALESCE($13, vendor_address),
        primary_contact_name = COALESCE($14, primary_contact_name),
        primary_contact_number = COALESCE($15, primary_contact_number),
        secondary_contact_number = COALESCE($16, secondary_contact_number),
        secondary_contact_name = COALESCE($17, secondary_contact_name),
        items = COALESCE($18, items),
        discount = COALESCE($19, discount),
        discount_amount = COALESCE($20, discount_amount),
        after_discount = COALESCE($21, after_discount),
        cgst = COALESCE($22, cgst),
        cgst_amount = COALESCE($23, cgst_amount),
        sgst = COALESCE($24, sgst),
        sgst_amount = COALESCE($25, sgst_amount),
        total_amount = COALESCE($26, total_amount),
        delivery = COALESCE($27, delivery),
        payment = COALESCE($28, payment),
        notes = COALESCE($29, notes),
        status = COALESCE($30, status),
        updated_at = CURRENT_TIMESTAMP
      WHERE po_id = $31 RETURNING *`,
      [
        sample_id,
        company_name,
        company_subtitle,
        company_email,
        company_gst,
        indent_no,
        indent_date,
        order_no,
        po_date,
        vendor_name,
        site,
        contact_person,
        vendor_address,
        primary_contact_name,
        primary_contact_number,
        secondary_contact_number,
        secondary_contact_name,
        items ? JSON.stringify(items) : null,
        discount,
        discount_amount,
        after_discount,
        cgst,
        cgst_amount,
        sgst,
        sgst_amount,
        total_amount,
        delivery,
        payment,
        notes,
        status,
        id,
      ]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: "PO not found" });
    }
    res.json(result.rows[0]);

    // Log Activity
    logActivity({
      action: "updated",
      entity_type: "po",
      entity_id: id,
      entity_name: `PO #${result.rows[0].po_id}`,
      performed_by: req.body.user_id || null,
      performed_by_name: req.body.user_name || null,
      project_id: result.rows[0].project_id,
      meta: { updates: req.body }
    });
  } catch (error) {
    console.error("Error updating PO:", error);
    res.status(500).json({ error: error.message });
  }
});

/**
 * @swagger
 * /api/po/{id}:
 *   delete:
 *     summary: Delete a PO
 *     tags: [PO]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: PO ID
 *     responses:
 *       200:
 *         description: PO deleted successfully
 *       404:
 *         description: PO not found
 *       500:
 *         description: Internal server error
 */
router.delete("/:id", async (req, res) => {
  const { id } = req.params;
  try {
    const result = await pool.query("DELETE FROM pos WHERE po_id = $1 RETURNING *", [id]);
    if (result.rows.length === 0) {
      return res.status(404).json({ error: "PO not found" });
    }
    res.json({ message: "PO deleted successfully" });
    logActivity({
  action: "deleted",
  entity_type: "po",
  entity_id: id,
  entity_name: `PO #${id}`,
  performed_by: null,
  performed_by_name: null,
});

  } catch (error) {
    console.error("Error deleting PO:", error);
    res.status(500).json({ error: error.message });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// ROUTE 1: Generate PO PDF from DB and return as download
// GET /api/po/:id/pdf
// ─────────────────────────────────────────────────────────────────────────────

/**
 * @swagger
 * /api/po/{id}/pdf:
 *   get:
 *     summary: Generate and download a PDF for a PO
 *     tags: [PO]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: PO ID
 *     responses:
 *       200:
 *         description: PDF file stream
 *         content:
 *           application/pdf:
 *             schema:
 *               type: string
 *               format: binary
 *       404:
 *         description: PO not found
 *       500:
 *         description: Internal server error
 */
router.get("/:id/pdf", async (req, res) => {
  const { id } = req.params;
  try {
    // 1. Fetch PO from DB
    const result = await pool.query("SELECT * FROM pos WHERE po_id = $1", [id]);
    if (result.rows.length === 0) {
      return res.status(404).json({ error: "PO not found" });
    }

    const po = result.rows[0];

    // 2. Generate PDF buffer
    const pdfBuffer = await generatePOPdf(po);

    // 3. Send as downloadable PDF
    const filename = `PO_${po.order_no || id}_${Date.now()}.pdf`;
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
    res.setHeader("Content-Length", pdfBuffer.length);
    res.send(pdfBuffer);

  } catch (error) {
    console.error("Error generating PO PDF:", error);
    res.status(500).json({ error: error.message });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// ROUTE 2: Send PO Email to Vendor with PDF attachment
// POST /api/po/:id/send-email
//
// Request Body (JSON):
// {
//   "to"          : "vendor@example.com",   // required — vendor's email
//   "cc"          : ["mgr@co.com"],          // optional — array of CC addresses
//   "message"     : "Please find the PO...", // optional — custom message body
//   "user_id"     : 1,                       // optional — for activity log
//   "user_name"   : "Admin"                  // optional — for activity log
// }
// ─────────────────────────────────────────────────────────────────────────────

/**
 * @swagger
 * /api/po/{id}/send-email:
 *   post:
 *     summary: Send PO details to a vendor via email with PDF attachment
 *     tags: [PO]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: PO ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - to
 *             properties:
 *               to:
 *                 type: string
 *                 description: Vendor email address
 *                 example: vendor@example.com
 *               cc:
 *                 type: array
 *                 items:
 *                   type: string
 *                 description: CC email addresses
 *                 example: ["manager@company.com"]
 *               message:
 *                 type: string
 *                 description: Custom message body (HTML supported)
 *                 example: "Please find the attached Purchase Order for your reference."
 *               user_id:
 *                 type: integer
 *               user_name:
 *                 type: string
 *     responses:
 *       200:
 *         description: Email sent successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                 messageId:
 *                   type: string
 *       400:
 *         description: Missing required fields
 *       404:
 *         description: PO not found
 *       500:
 *         description: Internal server error / email send failed
 */
router.post("/:id/send-email", async (req, res) => {
  const { id } = req.params;
  const { to, cc, message, user_id, user_name } = req.body;

  // ── Validate ──────────────────────────────────────────────────────────────
  if (!to) {
    return res.status(400).json({ error: "Recipient email address ('to') is required." });
  }

  try {
    // 1. Fetch PO from DB
    const result = await pool.query("SELECT * FROM pos WHERE po_id = $1", [id]);
    if (result.rows.length === 0) {
      return res.status(404).json({ error: "PO not found" });
    }
    const po = result.rows[0];

    // 2. Generate PDF
    const pdfBuffer = await generatePOPdf(po);
    const pdfFilename = `PO_${po.order_no || id}.pdf`;

    // 3. Build Nodemailer transporter from env vars
    //    Add these to your .env:
    //      SMTP_HOST=smtp.gmail.com
    //      SMTP_PORT=587
    //      SMTP_SECURE=false          (true for port 465)
    //      SMTP_USER=your@gmail.com
    //      SMTP_PASS=your_app_password
    //      SMTP_FROM="Madhuram Enterprises <your@gmail.com>"
    const transporter = nodemailer.createTransport({
      host:   process.env.SMTP_HOST,
      port:   Number(process.env.SMTP_PORT) || 587,
      secure: process.env.SMTP_SECURE === "true",
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS,
      },
    });

    // 4. Build PO summary table for the email body (HTML)
    const formatDate = (d) => {
      if (!d) return "-";
      const dt = new Date(d);
      return isNaN(dt) ? d : dt.toLocaleDateString("en-IN");
    };

    let items = po.items || [];
    if (typeof items === "string") {
      try { items = JSON.parse(items); } catch { items = []; }
    }

    const itemRows = items
      .filter((item) => !isNaN(parseInt(item.srno)))
      .map(
        (item) => `
        <tr>
          <td style="border:1px solid #ddd;padding:6px;text-align:center;">${item.srno ?? ""}</td>
          <td style="border:1px solid #ddd;padding:6px;">${item.hsn ?? ""}</td>
          <td style="border:1px solid #ddd;padding:6px;">${item.description ?? ""}</td>
          <td style="border:1px solid #ddd;padding:6px;text-align:center;">${item.qty ?? ""}</td>
          <td style="border:1px solid #ddd;padding:6px;text-align:center;">${item.UOM ?? ""}</td>
          <td style="border:1px solid #ddd;padding:6px;text-align:right;">₹${parseFloat(item.Rate || 0).toFixed(2)}</td>
          <td style="border:1px solid #ddd;padding:6px;text-align:right;">₹${parseFloat(item.Amount || 0).toFixed(2)}</td>
        </tr>`
      )
      .join("");

    const customMessage = message
      ? `<p style="margin:12px 0;color:#333;">${message}</p>`
      : `<p style="margin:12px 0;color:#333;">Please find the attached Purchase Order for your reference. Kindly acknowledge receipt and confirm acceptance at the earliest.</p>`;

    const htmlBody = `
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"></head>
<body style="font-family:Arial,sans-serif;color:#222;max-width:700px;margin:auto;padding:20px;">

  <!-- Header -->
  <div style="background:#1a1a2e;padding:20px;border-radius:8px 8px 0 0;text-align:center;">
    <h1 style="color:#fff;margin:0;font-size:22px;">${po.company_name || "MADHURAM ENTERPRISES"}</h1>
    <p style="color:#aabbee;margin:4px 0;font-size:12px;">${po.company_subtitle || "PLUMBING & FIRE FIGHTING CONTRACTORS"}</p>
    ${po.company_gst ? `<p style="color:#fff;margin:4px 0;font-size:11px;">GST: ${po.company_gst}</p>` : ""}
  </div>

  <!-- PO Title Band -->
  <div style="background:#4a90d9;padding:10px;text-align:center;">
    <h2 style="color:#fff;margin:0;font-size:16px;letter-spacing:2px;">PURCHASE ORDER</h2>
  </div>

  <!-- PO Details -->
  <div style="background:#f5f7fa;padding:16px;border:1px solid #ddd;">
    <table width="100%" cellspacing="0" cellpadding="0">
      <tr>
        <td width="50%">
          <p style="margin:4px 0;font-size:13px;"><b>Order No:</b> ${po.order_no || "-"}</p>
          <p style="margin:4px 0;font-size:13px;"><b>PO Date:</b> ${formatDate(po.po_date)}</p>
          <p style="margin:4px 0;font-size:13px;"><b>Vendor:</b> ${po.vendor_name || "-"}</p>
        </td>
        <td width="50%">
          <p style="margin:4px 0;font-size:13px;"><b>Indent No:</b> ${po.indent_no || "-"}</p>
          <p style="margin:4px 0;font-size:13px;"><b>Indent Date:</b> ${formatDate(po.indent_date)}</p>
          <p style="margin:4px 0;font-size:13px;"><b>Site:</b> ${po.site || "-"}</p>
        </td>
      </tr>
    </table>
  </div>

  <!-- Custom message -->
  <div style="padding:12px 16px;">
    ${customMessage}
  </div>

  <!-- Items Table -->
  <div style="padding:0 0 12px;">
    <table width="100%" cellspacing="0" cellpadding="0" style="border-collapse:collapse;font-size:12px;">
      <thead>
        <tr style="background:#1a1a2e;color:#fff;">
          <th style="border:1px solid #555;padding:8px;text-align:center;">Sr</th>
          <th style="border:1px solid #555;padding:8px;">HSN</th>
          <th style="border:1px solid #555;padding:8px;">Description</th>
          <th style="border:1px solid #555;padding:8px;text-align:center;">Qty</th>
          <th style="border:1px solid #555;padding:8px;text-align:center;">UOM</th>
          <th style="border:1px solid #555;padding:8px;text-align:right;">Rate</th>
          <th style="border:1px solid #555;padding:8px;text-align:right;">Amount</th>
        </tr>
      </thead>
      <tbody>${itemRows}</tbody>
    </table>
  </div>

  <!-- Tax Summary -->
  <div style="text-align:right;padding:0 0 16px;">
    <table style="margin-left:auto;font-size:13px;border-collapse:collapse;">
      ${po.cgst ? `<tr><td style="padding:4px 12px;color:#555;">CGST (${po.cgst}%)</td><td style="padding:4px 12px;text-align:right;">₹${parseFloat(po.cgst_amount || 0).toFixed(2)}</td></tr>` : ""}
      ${po.sgst ? `<tr><td style="padding:4px 12px;color:#555;">SGST (${po.sgst}%)</td><td style="padding:4px 12px;text-align:right;">₹${parseFloat(po.sgst_amount || 0).toFixed(2)}</td></tr>` : ""}
      <tr style="background:#1a1a2e;color:#fff;">
        <td style="padding:8px 16px;font-weight:bold;">Total Amount</td>
        <td style="padding:8px 16px;font-weight:bold;text-align:right;">₹${parseFloat(po.total_amount || 0).toFixed(2)}</td>
      </tr>
    </table>
  </div>

  <!-- Delivery / Payment -->
  <div style="background:#f5f7fa;padding:12px 16px;border:1px solid #ddd;border-radius:4px;font-size:12px;">
    <b>Delivery:</b> ${po.delivery || "-"} &nbsp;&nbsp;|&nbsp;&nbsp;
    <b>Payment:</b> ${po.payment || "-"} &nbsp;&nbsp;|&nbsp;&nbsp;
    <b>Discount:</b> ${po.discount ? po.discount + "%" : "Nil"}
  </div>

  <!-- Footer -->
  <div style="background:#1a1a2e;padding:14px;text-align:center;margin-top:20px;border-radius:0 0 8px 8px;">
    <p style="color:#aabbee;margin:0;font-size:11px;">
      ${po.company_name || "MADHURAM ENTERPRISES"} &nbsp;|&nbsp;
      ${po.company_email || ""} &nbsp;|&nbsp; GST: ${po.company_gst || ""}
    </p>
    <p style="color:#7788aa;margin:4px 0 0;font-size:10px;">This is a system-generated email. Please do not reply directly to this email.</p>
  </div>

</body>
</html>`;

    const emailSubject = `Purchase Order ${po.order_no || "#" + id} – ${po.company_name || "Madhuram Enterprises"}`;

    // 5. Send email
    const mailOptions = {
      from:        process.env.SMTP_FROM || process.env.SMTP_USER,
      to:          to,
      cc:          cc && cc.length > 0 ? cc.join(",") : undefined,
      subject:     emailSubject,
      html:        htmlBody,
      attachments: [
        {
          filename:    pdfFilename,
          content:     pdfBuffer,
          contentType: "application/pdf",
        },
      ],
    };

    let emailStatus   = "sent";
    let emailError    = null;
    let nodemailerMsgId = null;

    try {
      const info = await transporter.sendMail(mailOptions);
      nodemailerMsgId = info.messageId;
    } catch (sendErr) {
      emailStatus = "failed";
      emailError  = sendErr.message;
      console.error("Nodemailer send error:", sendErr);
    }

    // 6. Save email log to DB (always — even on failure)
    try {
      await pool.query(
        `INSERT INTO po_email_logs (
          po_id, sent_to, cc_addresses, subject, custom_message,
          pdf_filename, status, error_message, nodemailer_msg_id,
          sent_by_user_id, sent_by_name
        ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`,
        [
          id,
          to,
          cc && cc.length > 0 ? cc : null,   // TEXT[] — pass JS array directly
          emailSubject,
          message || null,
          pdfFilename,
          emailStatus,
          emailError,
          nodemailerMsgId,
          user_id   || null,
          user_name || null,
        ]
      );
    } catch (dbErr) {
      // Don't fail the request if only the log insert fails — just warn
      console.error("Warning: could not save email log to DB:", dbErr.message);
    }

    // 7. Activity log
    logActivity({
      action:            emailStatus === "sent" ? "email_sent" : "email_failed",
      entity_type:       "po",
      entity_id:         id,
      entity_name:       `PO #${po.order_no || id}`,
      performed_by:      user_id   || null,
      performed_by_name: user_name || null,
      meta: { to, cc, nodemailerMsgId, status: emailStatus },
    });

    // 8. Respond
    if (emailStatus === "failed") {
      return res.status(500).json({
        error:   "Email sending failed. Details saved to log.",
        details: emailError,
      });
    }

    return res.status(200).json({
      message:    "Email sent successfully",
      messageId:  nodemailerMsgId,
      to,
      cc:         cc || [],
      log_saved:  true,
    });

  } catch (error) {
    console.error("Error in send-email route:", error);
    res.status(500).json({ error: error.message });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// ROUTE 3: Get email logs for a PO
// GET /api/po/:id/email-logs
// ─────────────────────────────────────────────────────────────────────────────

/**
 * @swagger
 * /api/po/{id}/email-logs:
 *   get:
 *     summary: Get all email send history for a PO
 *     tags: [PO]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: PO ID
 *     responses:
 *       200:
 *         description: List of email logs
 *       500:
 *         description: Internal server error
 */
router.get("/:id/email-logs", async (req, res) => {
  const { id } = req.params;
  try {
    const result = await pool.query(
      `SELECT
         log_id, po_id, sent_to, cc_addresses, subject,
         custom_message, pdf_filename, status, error_message,
         nodemailer_msg_id, sent_by_user_id, sent_by_name, sent_at
       FROM po_email_logs
       WHERE po_id = $1
       ORDER BY sent_at DESC`,
      [id]
    );
    res.json(result.rows);
  } catch (error) {
    console.error("Error fetching email logs:", error);
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;